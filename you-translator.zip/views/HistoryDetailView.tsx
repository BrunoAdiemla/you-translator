
import React, { useMemo } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { UserProfile } from '../types';
import { storageService } from '../services/storageService';
import { translations } from '../translations';
import { ArrowLeft, Bot, Sparkles, Quote } from 'lucide-react';

interface HistoryDetailProps {
  profile: UserProfile;
}

const HistoryDetailView: React.FC<HistoryDetailProps> = ({ profile }) => {
  const { id } = useParams();
  const navigate = useNavigate();
  const history = useMemo(() => storageService.getHistory(), []);
  const attempt = useMemo(() => history.find(a => a.id === id), [history, id]);
  const t = translations[profile.nativeLanguage].history;
  const tp = translations[profile.nativeLanguage].practice;

  if (!attempt) {
    return (
      <div className="p-6 pt-10 flex flex-col items-center justify-center min-h-screen text-center space-y-4">
        <p className="text-slate-500">Tradução não encontrada.</p>
        <button onClick={() => navigate('/history')} className="text-indigo-600 font-bold">Voltar</button>
      </div>
    );
  }

  return (
    <div className="p-6 pt-10 pb-24 space-y-6 bg-white dark:bg-slate-900 min-h-screen">
      <header className="flex items-center space-x-4">
        <button 
          onClick={() => navigate('/history')}
          className="p-2 bg-slate-100 dark:bg-slate-800 rounded-xl text-slate-600 dark:text-slate-400 active:scale-90 transition-all"
        >
          <ArrowLeft size={20} />
        </button>
        <h1 className="text-xl font-bold text-slate-900 dark:text-white font-heading">{t.detailTitle}</h1>
      </header>

      <div className="space-y-6">
        {/* original phrase */}
        <div className="p-6 bg-slate-50 dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700">
          <p className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest mb-2">{tp.translateThis}</p>
          <h2 className="text-lg font-semibold text-slate-800 dark:text-slate-200 leading-relaxed font-heading">
            {/* Note: The storage doesn't store the original phrase currently in Attempt, 
                let's assume we can retrieve it or it's implicitly there. 
                Wait, looking at types.ts, ExerciseAttempt doesn't have originalPhrase. 
                Let's assume the user wants to see their work.
                FIX: If original phrase is missing from storage, we just show user's work.
            */}
            Exercício de Tradução
          </h2>
        </div>

        {/* User's Work */}
        <div className="space-y-2">
          <label className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest px-1">{t.yourTranslation}</label>
          <div className="w-full p-5 bg-white dark:bg-slate-800 border-2 border-slate-100 dark:border-slate-700 rounded-3xl text-slate-700 dark:text-slate-300 font-medium">
            <Quote size={16} className="text-indigo-400 mb-2" />
            <p className="text-lg italic">{attempt.userTranslation}</p>
          </div>
        </div>

        {/* AI feedback section (reusing PracticeView design) */}
        <div className="space-y-3">
          <div className="flex items-center space-x-2 px-1">
            <div className="p-1.5 bg-indigo-100 dark:bg-indigo-900/30 rounded-lg text-indigo-600 dark:text-indigo-400">
              <Bot size={20} />
            </div>
            <span className="font-bold text-slate-800 dark:text-slate-200 text-sm">{tp.result}</span>
          </div>
          
          <div className="relative group">
            <div className="absolute -top-3 right-4 px-3 py-1 bg-indigo-600 text-white text-[10px] font-black uppercase tracking-widest rounded-full shadow-lg z-10">
              AI Review
            </div>
            <div className="w-full min-h-[160px] p-5 bg-white dark:bg-slate-800 border-2 border-indigo-100 dark:border-indigo-900/50 rounded-3xl shadow-sm space-y-4">
              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <Sparkles size={14} className="text-amber-500" />
                  <p className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest">{tp.correction}</p>
                </div>
                <p className="text-slate-800 dark:text-slate-200 font-bold text-lg italic bg-slate-50 dark:bg-slate-900/50 p-3 rounded-xl border border-slate-100 dark:border-slate-700">
                  {attempt.evaluation.correction}
                </p>
              </div>

              <div className="space-y-1">
                <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
                  {attempt.evaluation.explanation}
                </p>
                <div className="pt-2 flex justify-end">
                   <span className={`px-3 py-1 rounded-lg font-black text-sm ${attempt.evaluation.score >= 7 ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400' : 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400'}`}>
                     {t.score} {attempt.evaluation.score}/10
                   </span>
                </div>
              </div>

              {attempt.evaluation.tips.length > 0 && (
                <div className="pt-2 border-t border-slate-100 dark:border-slate-700">
                  <p className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest mb-2">{tp.tips}</p>
                  <ul className="space-y-1">
                    {attempt.evaluation.tips.map((tip, i) => (
                      <li key={i} className="text-xs text-slate-600 dark:text-slate-400 flex items-start space-x-2">
                        <span className="text-indigo-500">•</span>
                        <span>{tip}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HistoryDetailView;
