
import React, { useMemo } from 'react';
import { UserProfile } from '../types';
import { storageService } from '../services/storageService';
import { LEVELS } from '../constants';
import { translations } from '../translations';

interface LeaderboardProps {
  profile: UserProfile;
}

const LeaderboardView: React.FC<LeaderboardProps> = ({ profile }) => {
  const users = useMemo(() => storageService.getLeaderboard(), []);
  const t = translations[profile.nativeLanguage].ranking;
  
  const allUsers = useMemo(() => {
    const list = [...users, { userId: profile.id, name: profile.name, points: profile.points, proficiency: profile.proficiency }];
    return list.sort((a, b) => b.points - a.points);
  }, [users, profile]);

  return (
    <div className="p-6 pt-10 space-y-6 bg-white dark:bg-slate-900 min-h-screen">
      <header className="text-center space-y-1">
        <h1 className="text-2xl font-bold text-slate-900 dark:text-white font-heading">{t.title}</h1>
        <p className="text-sm text-slate-500 dark:text-slate-400">{t.subtitle}</p>
      </header>

      <div className="flex items-end justify-center space-x-2 pt-10 pb-6">
        {allUsers.slice(0, 3).map((u, i) => {
          const positions = [1, 0, 2];
          const user = allUsers[positions[i]];
          if (!user) return null;
          
          const isWinner = positions[i] === 0;
          const isThird = positions[i] === 2;

          return (
            <div key={user.userId} className="flex flex-col items-center space-y-3">
              <div className={`relative ${isWinner ? 'scale-110 -translate-y-4' : 'scale-90'}`}>
                <div className={`w-16 h-16 rounded-full border-4 flex items-center justify-center text-xl font-bold ${
                  isWinner ? 'border-amber-400 bg-amber-50 dark:bg-amber-900/20 text-amber-600 dark:text-amber-400' :
                  isThird ? 'border-orange-300 bg-orange-50 dark:bg-orange-900/20 text-orange-600 dark:text-orange-400' :
                  'border-slate-300 bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
                }`}>
                  {user.name.charAt(0)}
                </div>
                <div className={`absolute -bottom-2 left-1/2 -translate-x-1/2 px-3 py-0.5 rounded-full text-[10px] font-bold text-white ${
                  isWinner ? 'bg-amber-400' : isThird ? 'bg-orange-400' : 'bg-slate-400'
                }`}>
                  #{positions[i] + 1}
                </div>
              </div>
              <div className="text-center">
                <p className="text-xs font-bold text-slate-800 dark:text-slate-200 w-20 truncate">{user.name}</p>
                <p className="text-[10px] font-bold text-indigo-600 dark:text-indigo-400 uppercase">{user.points} XP</p>
              </div>
            </div>
          );
        })}
      </div>

      <div className="bg-white dark:bg-slate-800 border border-slate-100 dark:border-slate-700 rounded-3xl overflow-hidden shadow-sm">
        {allUsers.map((user, index) => {
          const isMe = user.userId === profile.id;
          const levelInfo = LEVELS.find(l => l.id === user.proficiency);
          
          return (
            <div 
              key={user.userId} 
              className={`flex items-center p-4 space-x-4 border-b border-slate-50 dark:border-slate-700 last:border-0 ${isMe ? 'bg-indigo-50/50 dark:bg-indigo-900/20' : ''}`}
            >
              <div className="w-6 text-center text-xs font-black text-slate-400 dark:text-slate-600">
                {index + 1}
              </div>
              <div className="w-10 h-10 rounded-xl bg-slate-100 dark:bg-slate-700 flex items-center justify-center text-slate-600 dark:text-slate-400 font-bold">
                {user.name.charAt(0)}
              </div>
              <div className="flex-1">
                <div className="flex items-center space-x-2">
                  <p className={`text-sm font-bold ${isMe ? 'text-indigo-600 dark:text-indigo-400' : 'text-slate-800 dark:text-slate-200'}`}>
                    {user.name} {isMe && `(${t.you})`}
                  </p>
                  <span className={`text-[8px] font-bold px-1.5 py-0.5 rounded-full uppercase tracking-tighter ${levelInfo?.color}`}>
                    {levelInfo?.label}
                  </span>
                </div>
                <p className="text-[10px] text-slate-400 dark:text-slate-500 font-medium">{t.globalRanking}</p>
              </div>
              <div className="text-right">
                <p className="text-sm font-black text-slate-900 dark:text-white">{user.points}</p>
                <p className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-tighter">XP</p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default LeaderboardView;
