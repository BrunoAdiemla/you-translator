
import React from 'react';
import { UserProfile } from '../types';
import { ICONS, LEVELS } from '../constants';
import { useNavigate } from 'react-router-dom';
import { translations } from '../translations';

interface HomeProps {
  profile: UserProfile;
}

const HomeView: React.FC<HomeProps> = ({ profile }) => {
  const navigate = useNavigate();
  const t = translations[profile.nativeLanguage].home;
  const currentLevel = LEVELS.find(l => l.id === profile.proficiency);

  return (
    <div className="p-6 pt-10 space-y-6 bg-white dark:bg-slate-900 min-h-screen">
      <header className="flex items-center justify-between">
        <div>
          <p className="text-slate-400 dark:text-slate-500 text-sm font-medium">{t.welcome}</p>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white font-heading">{profile.name}!</h1>
        </div>
        {profile.avatar ? (
          <img 
            src={profile.avatar} 
            alt={profile.name} 
            className="w-12 h-12 rounded-full object-cover border-2 border-indigo-100 dark:border-indigo-900 shadow-sm"
          />
        ) : (
          <div className="w-12 h-12 bg-indigo-100 dark:bg-indigo-900/30 rounded-full flex items-center justify-center text-indigo-600 dark:text-indigo-400 font-bold text-xl">
            {profile.name.charAt(0)}
          </div>
        )}
      </header>

      <div className="bg-indigo-600 dark:bg-indigo-700 rounded-3xl p-6 text-white shadow-xl shadow-indigo-100 dark:shadow-none relative overflow-hidden">
        <div className="relative z-10 space-y-4">
          <div className="flex items-center justify-between">
            <span className="bg-white/20 backdrop-blur-md px-3 py-1 rounded-full text-xs font-bold uppercase tracking-widest">
              {currentLevel?.label}
            </span>
            <div className="flex items-center space-x-1">
              <span className="text-amber-400">🔥</span>
              <span className="font-bold">{profile.streak} {t.streak}</span>
            </div>
          </div>
          <div>
            <p className="text-indigo-100 text-sm">{t.totalScore}</p>
            <h2 className="text-4xl font-black font-heading">{profile.points} XP</h2>
          </div>
          <button 
            onClick={() => navigate('/practice')}
            className="w-full py-3 bg-white dark:bg-slate-100 text-indigo-600 rounded-xl font-bold flex items-center justify-center space-x-2 shadow-lg"
          >
            <span>{t.continuePractice}</span>
            {ICONS.Next}
          </button>
        </div>
        <div className="absolute -right-10 -bottom-10 w-40 h-40 bg-white/10 rounded-full blur-3xl"></div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="bg-white dark:bg-slate-800 border border-slate-100 dark:border-slate-700 p-4 rounded-2xl shadow-sm space-y-2">
          <div className="w-10 h-10 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 rounded-xl flex items-center justify-center">
            {ICONS.Success}
          </div>
          <div>
            <p className="text-2xl font-bold text-slate-900 dark:text-white">{profile.exercisesCompleted}</p>
            <p className="text-slate-400 dark:text-slate-500 text-xs">{t.completed}</p>
          </div>
        </div>
        <div className="bg-white dark:bg-slate-800 border border-slate-100 dark:border-slate-700 p-4 rounded-2xl shadow-sm space-y-2">
          <div className="w-10 h-10 bg-amber-100 dark:bg-amber-900/30 text-amber-600 dark:text-amber-400 rounded-xl flex items-center justify-center">
            {ICONS.Stats}
          </div>
          <div>
            <p className="text-2xl font-bold text-slate-900 dark:text-white">{profile.averageScore}/10</p>
            <p className="text-slate-400 dark:text-slate-500 text-xs">{t.average}</p>
          </div>
        </div>
      </div>

      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-bold text-slate-900 dark:text-white">{t.recentHistory}</h3>
          <button className="text-xs text-indigo-600 dark:text-indigo-400 font-bold uppercase tracking-wider">{t.viewAll}</button>
        </div>
        {profile.exercisesCompleted === 0 ? (
          <div className="bg-slate-50 dark:bg-slate-800 border-2 border-dashed border-slate-200 dark:border-slate-700 p-8 rounded-2xl text-center">
            <p className="text-slate-400 dark:text-slate-500 text-sm">{t.noExercises}</p>
          </div>
        ) : (
          <div className="space-y-3">
            <div className="p-4 bg-white dark:bg-slate-800 border border-slate-100 dark:border-slate-700 rounded-2xl flex items-center space-x-4">
              <div className="w-10 h-10 bg-indigo-50 dark:bg-indigo-900/20 rounded-full flex items-center justify-center text-indigo-600 dark:text-indigo-400">
                <span className="font-bold">#1</span>
              </div>
              <div className="flex-1">
                <p className="text-sm font-semibold text-slate-800 dark:text-slate-200 line-clamp-1">Translation exercise</p>
                <p className="text-[10px] text-slate-400 dark:text-slate-500 uppercase font-bold tracking-tighter">{t.yesterday} • 8.5 XP</p>
              </div>
              <div className="text-emerald-500 dark:text-emerald-400 font-bold">8.5</div>
            </div>
          </div>
        )}
      </section>
    </div>
  );
};

export default HomeView;
