
import React, { useState, useEffect } from 'react';
import { HashRouter, Routes, Route, useNavigate, useLocation, Navigate } from 'react-router-dom';
import { storageService } from './services/storageService';
import { UserProfile, Language, AuthSession } from './types';
import { ICONS } from './constants';
import { translations } from './translations';

// View components
import OnboardingView from './views/OnboardingView';
import HomeView from './views/HomeView';
import PracticeView from './views/PracticeView';
import LeaderboardView from './views/LeaderboardView';
import ProfileView from './views/ProfileView';
import HistoryListView from './views/HistoryListView';
import HistoryDetailView from './views/HistoryDetailView';
import AuthView from './views/AuthView';

const NavigationBar: React.FC<{ language: Language }> = ({ language }) => {
  const navigate = useNavigate();
  const location = useLocation();
  const t = translations[language].nav;

  const navItems = [
    { path: '/', label: t.home, icon: ICONS.Home },
    { path: '/practice', label: t.practice, icon: ICONS.Practice },
    { path: '/history', label: t.history, icon: ICONS.History },
    { path: '/ranking', label: t.ranking, icon: ICONS.Ranking },
    { path: '/profile', label: t.profile, icon: ICONS.Profile },
  ];

  return (
    <nav className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-[480px] bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 flex justify-around items-center h-16 px-2 z-50">
      {navItems.map((item) => {
        const isActive = location.pathname === item.path || (item.path === '/history' && location.pathname.startsWith('/history/'));
        return (
          <button
            key={item.path}
            onClick={() => navigate(item.path)}
            className={`flex flex-col items-center justify-center space-y-1 transition-colors flex-1 ${
              isActive ? 'text-indigo-600 dark:text-indigo-400' : 'text-slate-400 dark:text-slate-600'
            }`}
          >
            <div className={`transition-transform duration-200 ${isActive ? 'scale-110' : ''}`}>
              {item.icon}
            </div>
            <span className="text-[9px] font-bold uppercase tracking-tight truncate w-full text-center">{item.label}</span>
          </button>
        );
      })}
    </nav>
  );
};

const AppContent: React.FC = () => {
  const [session, setSession] = useState<AuthSession | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const authSession = storageService.getAuthSession();
    const userProfile = storageService.getProfile();
    setSession(authSession);
    setProfile(userProfile);
    setLoading(false);
  }, []);

  if (loading) return (
    <div className="h-screen flex items-center justify-center bg-white dark:bg-slate-950">
      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
    </div>
  );

  // Flow: Auth -> Onboarding -> Main App
  if (!session) {
    return <AuthView onAuthenticated={(s) => { setSession(s); }} language={Language.PORTUGUESE} />;
  }

  if (!profile) {
    return (
      <OnboardingView 
        onComplete={(p) => { 
          setProfile(p); 
          navigate('/'); 
        }} 
        prefilledName={session.user.name}
        prefilledEmail={session.user.email}
      />
    );
  }

  return (
    <div className={`${profile.theme === 'dark' ? 'dark' : ''} bg-slate-50 dark:bg-slate-950 min-h-screen`}>
      <div className="mobile-container relative pb-20 overflow-x-hidden bg-white dark:bg-slate-900 min-h-screen">
        <Routes>
          <Route path="/" element={<HomeView profile={profile} />} />
          <Route path="/practice" element={<PracticeView profile={profile} onUpdateProfile={setProfile} />} />
          <Route path="/history" element={<HistoryListView profile={profile} />} />
          <Route path="/history/:id" element={<HistoryDetailView profile={profile} />} />
          <Route path="/ranking" element={<LeaderboardView profile={profile} />} />
          <Route path="/profile" element={<ProfileView profile={profile} onUpdateProfile={setProfile} />} />
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
        <NavigationBar language={profile.nativeLanguage} />
      </div>
    </div>
  );
};

export default function App() {
  return (
    <HashRouter>
      <AppContent />
    </HashRouter>
  );
}
